#!/bin/sh
set -e

if [ -z "$FRP_VOIP_BIND_PORT" ] || [ -z "$FRP_TOKEN" ]; then
  echo "FRP_VOIP_BIND_PORT and FRP_TOKEN must both be set in .env" >&2
  exit 1
fi

cp /etc/frp/frps.toml.src /etc/frp/frps.toml

for var in FRP_VOIP_BIND_PORT FRP_TOKEN; do
  val=$(eval echo "\$$var")
  esc_val=$(printf '%s' "$val" | sed -e 's/[\/&]/\\&/g')
  sed -i "s/\${$var}/$esc_val/g" /etc/frp/frps.toml
done

exec frps -c /etc/frp/frps.toml
