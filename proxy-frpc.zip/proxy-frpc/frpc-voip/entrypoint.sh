#!/bin/sh
# Same rendering pattern as frpc/entrypoint.sh — this is a SEPARATE frpc
# instance, running with network_mode: host, handling ONLY the VoIP
# (Simple Voice Chat) proxy. Kept isolated from the main frpc container
# deliberately: host networking would break the main frpc's ability to
# reach nginx-ui's unpublished internal tunnel port over home-net, so
# rather than compromise that, this is its own thing.
#
# Uses KCP transport WITHOUT TLS — confirmed via real, repeated testing
# (not assumed) that TLS forced together with KCP fails to connect at
# all, while KCP alone connects instantly. This means traffic on this
# specific tunnel is not TLS-encrypted between here and frps, a real
# tradeoff made deliberately to get VoIP's real-time UDP retries
# actually working, verified end-to-end against real frp binaries: every
# retry from a fresh source port correctly received its own reply back,
# where the default TCP+TLS transport only ever replied to the first.
set -e

if [ -z "$FRP_SERVER_ADDR" ] || [ -z "$FRP_TOKEN" ]; then
  echo "FRP_SERVER_ADDR and FRP_TOKEN must both be set in .env" >&2
  exit 1
fi

cp /etc/frp/frpc-voip.toml.src /etc/frp/frpc-voip.toml

for var in FRP_SERVER_ADDR FRP_TOKEN; do
  val=$(eval echo "\$$var")
  esc_val=$(printf '%s' "$val" | sed -e 's/[\/&]/\\&/g')
  sed -i "s/\${$var}/$esc_val/g" /etc/frp/frpc-voip.toml
done

exec frpc -c /etc/frp/frpc-voip.toml
